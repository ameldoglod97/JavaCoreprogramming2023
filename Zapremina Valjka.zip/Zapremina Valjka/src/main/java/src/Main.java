package src;

public class Main {
    public static void main(String[] args) {
        double poluprecnik = 10;
        double visina = 50;
        double zapremina  = Math.PI * poluprecnik * poluprecnik * visina ;
        System.out.println("Zapremina valjka je : " + zapremina);
    }}